package com.rebel.cronicle.dao;

import com.rebel.cronicle.model.JobModel;
import org.springframework.data.repository.CrudRepository;

public interface JobRepository extends CrudRepository<JobModel, Long> {
	JobModel findByJobName(String JobName);

	Integer deleteByJobName(String JobName);
}
