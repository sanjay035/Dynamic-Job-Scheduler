package com.rebel.cronicle.util;

import com.rebel.cronicle.constants.JobConstants;
import com.rebel.cronicle.dao.CronAuditRepository;
import com.rebel.cronicle.model.CronAudit;
import com.rebel.cronicle.model.JobModel;
import com.rebel.cronicle.response.FailureResponse;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.RetryCallback;
import org.springframework.retry.RetryContext;
import org.springframework.retry.RetryListener;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.sql.Timestamp;
import java.util.Date;

@Service
public class RetryListenerImpl implements RetryListener {
	private final static Logger LOG = LoggerWrapper.getLogger(RestTemplateUtil.class);
	@Autowired
	CronAuditRepository objCronAuditRepository;

	@Override
	public <T, E extends Throwable> boolean open(RetryContext retryContext, RetryCallback<T, E> retryCallback) {
		return true;
	}

	@Override
	public <T, E extends Throwable> void close(RetryContext retryContext, RetryCallback<T, E> retryCallback, Throwable throwable) {
		JobModel model = (JobModel) retryContext.getAttribute("model");
		try {
			if (retryContext.getLastThrowable() != null) {
				String reasonOfFailure = retryContext.getLastThrowable().getMessage();
				if (reasonOfFailure == null || !reasonOfFailure.equals(JobConstants.CLIENT_SIDE_ISSUE)) {
					LOG.info("Inside Close >>>>>>  " + retryContext.getRetryCount() + "  >>>>  " + model);
					ResponseEntity<String> entity = (ResponseEntity<String>) retryContext.getAttribute("entity");
					FailureResponse failreponse = new FailureResponse();
					if (entity == null) {
						failreponse.setResponseCode(0);
						failreponse.setResponseBody(reasonOfFailure);
					} else {
						failreponse.setResponseCode(entity.getStatusCodeValue());
						failreponse.setHeaders(entity.getHeaders().toSingleValueMap());
						failreponse.setResponseBody(entity.getBody());
					}
					failreponse.setFailureReason(reasonOfFailure);
					failreponse.setJobId(model.getJobID());
					HttpEntity httpEntity = new HttpEntity(failreponse);
					saveExecutionAudit((CronAudit) retryContext.getAttribute("audit"), model, JobConstants.JobStatus.FAILURE.name(),
							failreponse.getFailureReason(), retryContext.getRetryCount(), reasonOfFailure, failreponse.getResponseBody());
					ResponseEntity<String> responseEntity = new RestTemplate().exchange(model.getCallbackUrl(), HttpMethod.POST, httpEntity,
							String.class);
					LOG.info("Call Back Response" + responseEntity);
				}
			} else
				saveExecutionAudit((CronAudit) retryContext.getAttribute("audit"), model, JobConstants.JobStatus.SUCCESS.name(), "",
						retryContext.getRetryCount(), "", "");
		} catch (Exception ex) {
			LOG.error("Callback Failure", ex);
		}
	}

	@Override
	public <T, E extends Throwable> void onError(RetryContext retryContext, RetryCallback<T, E> retryCallback, Throwable throwable) {
		JobModel model = (JobModel) retryContext.getAttribute("model");
		LOG.info("Inside OnError >>>>> " + retryContext.getRetryCount() + "  >>>>  " + model);
		String reasonOfFailure = retryContext.getLastThrowable().getMessage();
		try {
			if (reasonOfFailure.equals(JobConstants.CLIENT_SIDE_ISSUE)) {
				ResponseEntity<String> entity = (ResponseEntity<String>) retryContext.getAttribute("entity");
				FailureResponse failreponse = new FailureResponse();
				failreponse.setResponseCode(entity.getStatusCodeValue());
				failreponse.setHeaders(entity.getHeaders().toSingleValueMap());
				failreponse.setResponseBody(entity.getBody());
				failreponse.setFailureReason(reasonOfFailure);
				failreponse.setJobId(model.getJobID());
				HttpEntity httpEntity = new HttpEntity(failreponse);
				ResponseEntity<String> responseEntity = new RestTemplate().exchange(model.getCallbackUrl(), HttpMethod.POST, httpEntity,
						String.class);
//                LOG.info("Call Back Response" + responseEntity);
				saveExecutionAudit((CronAudit) retryContext.getAttribute("audit"), model, JobConstants.JobStatus.FAILURE.name(), "Client Side Issue",
						retryContext.getRetryCount(), reasonOfFailure, entity.getBody());
			}
		} catch (Exception ec) {
			LOG.error("Callback Failure", ec);
		}

	}

	private void saveExecutionAudit(CronAudit audit, JobModel model, String status, String reason, int retryNumber, String reasonOfFailure,
			String response) {
		audit.setEnd_time(new Timestamp(new Date().getTime()));
		audit.setRetryNumber(retryNumber + 1);
		audit.setStatus(status);
		audit.setResponseBody(response);
		audit.setLastFailureReason(reasonOfFailure);
		objCronAuditRepository.save(audit);
	}
}
