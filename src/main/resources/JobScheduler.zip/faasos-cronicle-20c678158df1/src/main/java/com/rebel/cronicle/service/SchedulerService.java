package com.rebel.cronicle.service;

import com.rebel.cronicle.constants.ErrorCodes;
import com.rebel.cronicle.constants.JobConstants;
import com.rebel.cronicle.dao.JobRepository;
import com.rebel.cronicle.exception.FinalException;
import com.rebel.cronicle.job.APITriggerJob;
import com.rebel.cronicle.model.JobModel;
import com.rebel.cronicle.requests.JobRequest;
import com.rebel.cronicle.response.JobResponse;
import com.rebel.cronicle.scheduler.JobScheduler;
import com.rebel.cronicle.util.JobUtil;
import com.rebel.cronicle.util.LoggerWrapper;
import com.rebel.cronicle.util.RequestValidatorUtil;
import org.quartz.SchedulerException;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Service
public class SchedulerService {
	private static final Logger LOG = LoggerWrapper.getLogger(SchedulerService.class);
	private final JobRepository jobRepository;
	private final JobScheduler jobScheduler;
	private final RequestValidatorUtil requestValidatorUtil;

	@Autowired
	public SchedulerService(JobScheduler jobScheduler, JobRepository jobRepository, RequestValidatorUtil requestValidatorUtil) {
		this.jobScheduler = jobScheduler;
		this.jobRepository = jobRepository;
		this.requestValidatorUtil = requestValidatorUtil;
	}

	public JobResponse insertJob(JobRequest jobRequest) throws FinalException {
		try {
			this.requestValidatorUtil.validateJobRequest(jobRequest);
			jobRequest.setIsActive(true);
			JobModel jobModel = JobUtil.getJobModel(jobRequest);
			jobModel = this.jobRepository.save(jobModel);
			jobRequest.setJobID(jobModel.getJobID());
			this.jobScheduler.insertJob(APITriggerJob.class, jobModel);
			return JobUtil.getJobResponse(jobModel);
		} catch (DataIntegrityViolationException de) {
			throw new FinalException(ErrorCodes.CLIENT_ERROR, de.getMessage());
		}
	}

	public JobResponse updateJob(JobRequest jobRequest) throws FinalException {
		try {
			this.requestValidatorUtil.validateJobRequest(jobRequest);
			JobModel jobModel = JobUtil.getJobModel(jobRequest);
			this.jobScheduler.updateJob(APITriggerJob.class, jobModel);
			jobModel = this.jobRepository.save(jobModel);
			return JobUtil.getJobResponse(jobModel);
		} catch (DataIntegrityViolationException de) {
			throw new FinalException(ErrorCodes.CLIENT_ERROR, de.getMessage());
		}
	}

	public JobModel getJobDetailsByID(long jobID) throws FinalException {
		try {
			return this.jobScheduler.getJobDetailsByID(jobID);
		} catch (DataIntegrityViolationException de) {
			throw new FinalException(ErrorCodes.CLIENT_ERROR, de.getMessage());
		}
	}

	@Transactional
	public String deleteJob(long jobID) throws FinalException {
		try {
			JobModel jobModel = this.jobScheduler.deleteJob(jobID);
			jobModel.setDeleted(true);
			jobModel.setActive(false);
			this.jobRepository.save(jobModel);
			return jobModel.isDeleted() ? JobConstants.JOB_DELETED : JobConstants.JOB_NOT_DELETED;
		} catch (DataIntegrityViolationException de) {
			throw new FinalException(ErrorCodes.CLIENT_ERROR, de.getMessage());
		}
	}

	public String activateJob(long jobID) throws FinalException {
		try {
			Optional<JobModel> jobModel = this.jobRepository.findById(jobID);
			if (!jobModel.isPresent() || jobModel.get().isDeleted())
				throw new FinalException(ErrorCodes.DELETED_JOB, JobConstants.JOB_NOT_AVAILABLE);
			boolean isActivated = this.jobScheduler.activateJob(jobID);
			jobModel.get().setActive(isActivated);
			this.jobRepository.save(jobModel.get());
			return isActivated ? JobConstants.JOB_ACTIVATED : JobConstants.JOB_NOT_ACTIVATED;
		} catch (DataIntegrityViolationException | SchedulerException de) {
			throw new FinalException(ErrorCodes.CLIENT_ERROR, de.getMessage());
		}
	}

	public String deactivateJob(long jobID) throws FinalException {
		try {
			boolean isDeactivated = this.jobScheduler.deactivateJob(jobID);
			Optional<JobModel> jobModel = this.jobRepository.findById(jobID);
			jobModel.get().setActive(!isDeactivated);
			this.jobRepository.save(jobModel.get());
			return isDeactivated ? JobConstants.JOB_DEACTIVATED : JobConstants.JOB_NOT_DEACTIVATED;
		} catch (DataIntegrityViolationException | SchedulerException de) {
			throw new FinalException(ErrorCodes.CLIENT_ERROR, de.getMessage());
		}
	}
}
