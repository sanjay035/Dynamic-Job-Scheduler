package com.rebel.cronicle.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rebel.cronicle.constants.JobConstants;
import com.rebel.cronicle.exception.RequestAssertionException;
import com.rebel.cronicle.model.JobModel;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.RetryContext;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

@Component
public class RestTemplateUtil {

	private final static Logger LOG = LoggerWrapper.getLogger(RestTemplateUtil.class);

	@Autowired
	private RestTemplate restTemplate;

	public void performRequest(JobModel jobModel, HttpMethod httpMethod, RetryContext context) throws RequestAssertionException {
		ResponseEntity<String> responseEntity = null;
		HttpEntity httpEntity = this.prepareHttpEntity(jobModel);
		try {
			responseEntity = this.restTemplate.exchange(jobModel.getRequestUrl(), httpMethod, httpEntity, String.class);
			LOG.info("Response entity " + responseEntity);
		} catch (Exception ex) {
			LOG.error("Error Found " + jobModel, ex.getMessage());
		}
		context.setAttribute("entity", responseEntity);
		if (responseEntity == null) {
			throw new RequestAssertionException(JobConstants.UNREACHABLE_SERVER_ISSUE);
		} else if (responseEntity.getStatusCode().is5xxServerError()) {
			throw new RequestAssertionException(JobConstants.SERVER_SIDE_ISSUE);
		} else if (responseEntity.getStatusCode().is4xxClientError()) {
			throw new RuntimeException(JobConstants.CLIENT_SIDE_ISSUE);
		}
	}

	public HttpEntity prepareHttpEntity(JobModel jobModel) {
		try {
			HttpHeaders headers = new HttpHeaders();
			ObjectMapper mapper = new ObjectMapper();
			JsonNode jsonNode = mapper.readTree(jobModel.getHeaders().toString());
			Map<String, String> result = mapper.convertValue(jsonNode, new TypeReference<>() {
			});
			if (result != null) {
				for (String key : result.keySet()) {
					headers.add(key, result.get(key));
				}
			}
			HttpEntity httpEntity = new HttpEntity(jobModel.getBody(), headers);
			return httpEntity;
		} catch (JsonProcessingException ex) {
			LOG.error(ex.getMessage());
		}
		return null;
	}
}