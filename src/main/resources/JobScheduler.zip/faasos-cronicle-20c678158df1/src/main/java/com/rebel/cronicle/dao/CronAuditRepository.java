package com.rebel.cronicle.dao;

import com.rebel.cronicle.model.CronAudit;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.transaction.annotation.Transactional;

public interface CronAuditRepository extends CrudRepository<CronAudit, Long> {
	@Transactional
	@Modifying
	@Query("UPDATE CronAudit audit SET audit.status = 'FAILURE' , audit.end_time = now() , audit.lastFailureReason = 'System Unexpected Down' WHERE (status = 'PENDING')")
	public void updateAllPendingJobs();
}
